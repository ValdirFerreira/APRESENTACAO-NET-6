﻿// See https://aka.ms/new-console-template for more information
using ConsoleDevNetCore;

Console.WriteLine("Hello, World!");

var classe = new MinhaClasse();
classe.MeuMetodo();
