﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleDevNetCore
{
    internal class MinhaClasse
    {

        public void MeuMetodo()
        {
            Console.WriteLine("Minha Mensagem");
        }

        public void meuMetodo2()
        {
            Console.WriteLine("Teste");
        }


    }
}
