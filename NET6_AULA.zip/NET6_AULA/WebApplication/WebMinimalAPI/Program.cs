var builder = WebApplication.CreateBuilder(args);
var app = builder.Build();

app.MapGet("/Usuarios", () => "Dev Net Core");
app.MapGet("/Data", () =>  DateTime.Now.ToLongDateString());

app.Run();
